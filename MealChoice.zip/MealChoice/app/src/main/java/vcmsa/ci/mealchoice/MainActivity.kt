package vcmsa.ci.mealchoice

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val inputTime = findViewById<EditText>(R.id.editTextTime)
        val suggestButton = findViewById<Button>(R.id.buttonSuggest)
        val resetButton = findViewById<Button>(R.id.buttonReset)
        val resultText = findViewById<TextView>(R.id.textViewResult)

        suggestButton.setOnClickListener {
            val timeOfDay = inputTime.text.toString().trim().lowercase()
            var mealSuggestion = "Please enter a valid time of day (Morning, Afternoon, Evening, or Night)."

            if (timeOfDay == "morning") {
                mealSuggestion = "How about fluffy pancakes with maple syrup, scrambled eggs, and a glass of fresh orange juice? Or smoothie bowl with granola and fresh berries could be great!"
            } else if (timeOfDay == "afternoon") {
                mealSuggestion = "For lunch, consider a grilled chicken wrap with avocado and a side of quinoa salad."
            } else if (timeOfDay == "evening") {
                mealSuggestion = "Try baked salmon with roasted sweet potatoes and sautéed spinach."
            } else if (timeOfDay == "night") {
                mealSuggestion = "Consider a bowl of Greek yogurt with honey and almonds, or a warm bowl of lentil soup. "
            }

            resultText.text = mealSuggestion
        }
        resetButton.setOnClickListener {
            inputTime.text.clear()
            resultText.text = ""
        }
    }
}


